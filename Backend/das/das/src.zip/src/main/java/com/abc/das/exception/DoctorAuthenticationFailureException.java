package com.abc.das.exception;

public class DoctorAuthenticationFailureException extends RuntimeException {
	public DoctorAuthenticationFailureException(String msg) {
		super(msg);
	}

}
