package com.abc.das.exception;

public class SlotNotFoundException extends RuntimeException
{
//	public SlotNotFoundException(String msg) {
//		super(msg);
//	}
	

}
