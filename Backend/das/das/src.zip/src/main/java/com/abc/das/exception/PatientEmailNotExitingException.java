package com.abc.das.exception;

public class PatientEmailNotExitingException extends RuntimeException {

	public PatientEmailNotExitingException(String msg) {
		super(msg);
	}
}


