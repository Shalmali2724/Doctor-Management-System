package com.abc.das.entity;

//import java.time.LocalDate;
//import java.time.LocalTime;
//import java.util.List;
//
//import javax.persistence.CascadeType;
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.Id;
//import javax.persistence.JoinColumn;
//import javax.persistence.JoinTable;
//import javax.persistence.ManyToMany;


//@Entity
public class Slots{
//	@Id
//	private int slot_id;
//
//	@ManyToMany(cascade = CascadeType.ALL)
//	@JoinTable(name="Doctor_Slot",joinColumns= {@JoinColumn(name="slot_id")},inverseJoinColumns = {@JoinColumn(name = "doctor_id")})
//
//	List<Doctor> doctor;
//
//	private LocalTime time;
//	private LocalDate date_of_available;
//	@Column(length = 20)
//	private String status;
//
//	public int getSlot_id() {
//		return slot_id;
//	}
//
//	public void setSlot_id(int slot_id) {
//		this.slot_id = slot_id;
//	}
//
//	
//	public List<Doctor> getDoctor() {
//		return doctor;
//	}
//
//	public void setDoctor(List<Doctor> doctor) {
//		this.doctor = doctor;
//	}
//
//	public LocalTime getTime() {
//		return time;
//	}
//
//	public void setTime(LocalTime time) {
//		this.time = time;
//	}
//
//	public LocalDate getDate_of_available() {
//		return date_of_available;
//	}
//
//	public void setDate_of_available(LocalDate date_of_available) {
//		this.date_of_available = date_of_available;
//	}
//
//	public String getStatus() {
//		return status;
//	}
//
//	public void setStatus(String status) {
//		this.status = status;
//	}

}
