package com.abc.das.repository;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.abc.das.entity.Slots;

//@Repository
public interface SlotRepository {//extends JpaRepository<Slots,Integer>{

//	Optional<Slots> findByDate(LocalDate date_of_available);
//
//	Optional<Slots> findByTime(LocalTime time);

//	Optional<Slots> findStatus(String status);

	
}
