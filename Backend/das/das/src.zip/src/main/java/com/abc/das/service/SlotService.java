package com.abc.das.service;

import java.time.LocalDate;
import java.time.LocalTime;

import com.abc.das.entity.Slots;
import com.abc.das.entity.Slots;
import com.abc.das.exception.SlotNotFoundException;

public interface SlotService 
{
//	public Slots getSlotbyId(int slot_id);
//	public Slots getDateOfAvailability(LocalDate date_of_available);
//	public Slots getStatus(String status);
//	public Slots getTimeById(LocalTime time);
	
	
	

}
