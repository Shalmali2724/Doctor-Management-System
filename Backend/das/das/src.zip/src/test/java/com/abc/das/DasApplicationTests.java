package com.abc.das;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DasApplicationTests {

	@Test
	void contextLoads() {
	}

}
